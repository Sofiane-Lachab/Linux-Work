#!/bin/bash
wget https://raw.githubusercontent.com/s7117/csce215labs/main/mnist_condensed.csv -O mnist_condensed.csv
head mnist_condensed.csv | tail +8 > lab06.out
wc -l < lab06.out
head -23 mnist_condensed.csv | tail +23 > lab06.out
cat | wc -l mnist_condensed.csv
head mnist_condensed.csv | tail +8 >> lab06.out
wc -l < lab06.out
head -23 mnist_condensed.csv | tail +23 >> lab06.out
cat | wc -l lab06.out
mkdir dir{A..Z}
mkdir dir113 dir
mkdir OLD
mv dir* mnist_condensed.csv OLD
rm -rf OLD
