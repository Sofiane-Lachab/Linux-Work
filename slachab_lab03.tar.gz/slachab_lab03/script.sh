#!/bin/bash

hostname
whoami
echo "Hello World"
pwd
mkdir dirA dirB dirC
ls
cd dirA
touch fileA
cd ../dirB
touch fileB
cd ../dirC
touch fileC
cd ../dirA
ls
cd ../dirB
ls
cd ../dirC
ls
cd ..
rm -r dirA dirB dirC
