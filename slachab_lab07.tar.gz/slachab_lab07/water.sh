#!/bin/bash
echo "REP --> How many ounces of water would you like today?"
read WATER
echo "REP --> Ok! "$WATER" ounces coming up!"
mkdir -p cart
echo "" > cart/water.item
for i in {0..$WATER};
do
 echo "water$i, " >> cart/water.item
done
