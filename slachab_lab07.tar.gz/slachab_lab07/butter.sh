#!/bin/bash

BUTTER=$1
BUTTEROZ=$(($BUTTER*4))
echo "LOG --> Shopping for "$BUTTER" sticks a.k.a "$BUTTEROZ ounces of butter...
mkdir -p cart
echo "" >> cart/butter.item
for i in {0..$BUTTER}
do
 echo "butter"$i", " >> cart/butter.item
done
