#!/bin/bash
FLOUR=$1
echo "LOG --> Shopping for "$FLOUR" ounces of flour at the grocery store..."
mkdir -p cart
echo "" > cart/flour.item
for i in {0..$FLOUR}
do
 echo "flour"$i", " >> cart/flour.item
done
