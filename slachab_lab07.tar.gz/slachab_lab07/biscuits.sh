#!/bin/bash

echo "REP --> How long would you like to bake the buscuits at 350 degrees Farenheit for?"
read BAKETIME
if [ "$BAKETIME" -gt "10" ]; then
	mv ./tray_of_raw_biscuits burnt_biscuits | echo "You burnt your biscuits!"
elif [ "$BAKETIME" -lt "10" ]; then
	mv ./tray_of_raw_biscuits still_raw_biscuits | echo "They are RAW -GR"
else
	mv ./tray_of_raw_biscuits perfect_biscuits | echo "Mmm! Golden rown biscuits! Yum"
fi

